package com.example.phamarcy_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class login_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}